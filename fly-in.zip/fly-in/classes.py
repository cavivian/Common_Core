# qui devo creare le classi per i droni, le zone e le connessioni, ma anche quella per la flotta (per rispondere alle domande sull'insieme)
# i droni hanno bisogno di: - sapere l'index, - sapere dove si trova, -di sapere se si trova alla fine, - il percorso:
# Sotto la parola "percorso" ci sono due cose diverse, e servono a cose diverse:
#	- il percorso pianificato: le zone che il drone dovrà ancora attraversare. Serve alla simulazione per 
# 	decidere la prossima mossa;
#	- la cronologia: dove è stato a ogni turno. Serve per scrivere l'output e per la grafica.
# capire le connessioni di che info hanno bisogno
# capire le zone di che info hanno bisogno
COUNT: int = 0

class Drone:
    """This class represents the info about a Drone"""

    def __init__(self, drone_id: int, start: str) -> None:
        self.drone_id = drone_id  # indice del drone
        self.zone: str = start  # mi dice il nome della zona in cui si trova
        self.connection: str | None = None  # mi dice il nome della connessione in cui si trova

    def go(self, update: str) -> None:
        """Updating the zone name when the drone moves on"""
        self.zone = update

    def go_to_connection_from_zone(self, update_connection: str) -> None:
        """Updating the connection name when the drone moves on"""
        self.connection = update_connection

    def go_to_zone(self, update_zone: str) -> None:
        """Updating the zone name and resets connection name to None when the drone moves on"""
        self.zone = update_zone
        self.connection = None

# per questa classe necessito anche dell'end_zone
class Fleet():
    """This Class contains all the information about all drones, if they all have finished
    the map"""

    def __init__(self, start_zone: str, nb_drones: int, end_zone: str) -> None:
        self.start_zone = start_zone
        self.nb_drones = nb_drones
        self.end_zone = end_zone
        print(start_zone)
        print(end_zone)

    def create_list_of_class_drones(self, ) -> list[Drone]:
        """This creates a list of all drones passed. For each it creates
        a separate class Drone"""
        storage: list[Drone] = []
        drone = 1
        for drone in range(self.nb_drones):
            storage.append(Drone(drone, self.start_zone))  # corretto, crea una lista di 8 elementi
        return storage

    def check_if_end(self,) -> str:
        """This method checks if all drones have finished the simulation"""
        storage = self.create_list_of_class_drones()
        for drones in storage:
            if drones.zone == self.end_zone:
                if COUNT == self.nb_drones:
                    return ("All drones have finished")
                COUNT += 1

class Connections:
    def __init__(self, connections):
        self.connections = connections
        pass


class Zones:
    def __init__(self, zones):
        self.zones = zones
        pass
        