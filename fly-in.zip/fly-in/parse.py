# cosa devo fare:
# - try-except in cui leggo i file dei percorsi(basta farlo con sys)
# - fare il parse di tutti i file (sempre dentro il try, di quello che
# viene passato in input)
import re
from typing import Any

DRONES = r"(?:nb_drones):\s(?P<numbers>\d+)"
COMPLETE_STRUCTURE = r"""(?P<kind>hub|start_hub|end_hub):\s
                         (?P<name>[^\s-]+)
                         \s(?P<x>-?\d+)\s
                         (?P<y>-?\d+)
                         (?:\s\[(?P<tags>\w+=[^\s=\[\]]+(?:\s\w+=[^\s=\[\]]+)*)
                         \])?"""
CONNECTIONS = r"""(?:connection):\s
                  (?P<zone1>[^\s\-\[\]]+)-(?P<zone2>[^\s\-\[\]]+)
                  (?:\s\[(?P<tags>\w+=[^\s=\[\]]+(?:\s\w+=[^\s=\[\]]+)*)\])?"""
ZONE_DEFAULTS: dict[str, str] = {"zone": "normal", "max_drones": "1"}
LINK_DEFAULTS: dict[str, str] = {"max_link_capacity": "1"}
VALID_ZONES = {"normal", "blocked", "restricted", "priority"}


class ParseError(Exception):
    def __init__(self, index: int, cause: str):
        self.index = index
        self.cause = cause
        super().__init__(f"line {index}: {cause}")


class Parse:
    def __init__(self, path: str) -> None:
        self.path = path
        self.connections = []
        self.zone = []
        self.nb_drones: int | None = None

    def open(self):
        with open(self.path, 'r') as f:
            for i, line in enumerate(f, start=0):
                try:
                    self.correct_format(line)
                except ValueError as e:
                    raise ParseError(i, str(e)) from e
            self.check_all()
            # print(f"I'm {line} at index {i}")
    # in questa funzione non sto salvando l'indice o il nome di dove

    # trovo l'errore
    def correct_format(self, content: str) -> str:
        self.line = content.strip()
        if self.line.startswith('#') or self.line == "":
            pass
        else:
            match_drones = re.fullmatch(DRONES, self.line, re.VERBOSE)
            match = re.fullmatch(COMPLETE_STRUCTURE, self.line, re.VERBOSE)
            match_connections = re.fullmatch(CONNECTIONS, self.line,
                                             re.VERBOSE)
            if match_drones:
                if not match_drones:
                    raise ValueError(f"Missing line before '{self.line}'")
                self.drones_match(match_drones)
            elif match:
                self.match_zones(match)
            elif match_connections:
                self.connections_match(match_connections)
            else:
                raise ValueError(f"invalid line: '{self.line}'")

    def drones_match(self, match_drones: re.Match[str]):
        result = match_drones.groupdict()
        # self.drones.append(result)
        result['numbers'] = int(result['numbers'])
        if result['numbers'] <= 0:
            raise ValueError("nb_drones must be positive")
        if self.nb_drones is not None:
            raise ValueError("nb_drones defined more than once")
        self.nb_drones = result['numbers']

    def match_zones(self, match: re.Match[str]):
        result = match.groupdict()
        # print(result)
        result['tags'] = self.give_default(self.create_a_dict(
            result['tags']), ZONE_DEFAULTS)
        result['x'] = int(result['x'])
        result['y'] = int(result['y'])
        try:
            result['tags']['max_drones'] = int(result['tags']['max_drones'])
        except ValueError as e:
            raise ValueError("max_drones must be an integer") from e
        if result['tags']['zone'] not in VALID_ZONES:
            raise ValueError(f"""invalid zone type '{result['tags']
                                                   ['zone']}'""")
        if result['tags']['max_drones'] <= 0:
            raise ValueError("max_drones must be positive")
        if any(z['name'] == result['name'] for z in self.zone):
            raise ValueError(f"duplicate zone name '{result['name']}'")
        self.zone.append(result)

    def connections_match(self, match_connections: re.Match[str]):
        result = match_connections.groupdict()
        result['tags'] = self.give_default(self.create_a_dict(
            result['tags']), LINK_DEFAULTS)
        try:
            result['tags']['max_link_capacity'] = int(result['tags']
                                                      ['max_link_capacity']
                                                      )
        except ValueError as e:
            raise ValueError("max_link_capacity must be an integer.") from e
        if result['tags']['max_link_capacity'] <= 0:
            raise ValueError("max_link_capacity must be positive")
        if result['zone1'] == result['zone2']:
            raise ValueError(f"""connection links zone
             '{result['zone1']}' to itself""")
        known = {z['name'] for z in self.zone}
        for name in (result['zone1'], result['zone2']):
            if name not in known:
                raise ValueError(f"connection uses unknown zone '{name}'")
        key = frozenset((result['zone1'], result['zone2']))
        if any(frozenset((c['zone1'], c['zone2'])) == key
               for c in self.connections):
            raise ValueError(f"duplicate connection "
                             f"{result['zone1']}-{result['zone2']}")
        self.connections.append(result)

    def check_all(self) -> None:
        if self.nb_drones is None:
            raise ValueError("nb_drones is missing")
        kinds = [z['kind'] for z in self.zone]
        if kinds.count('start_hub') != 1:
            raise ValueError("there must be exactly one start_hub")
        if kinds.count('end_hub') != 1:
            raise ValueError("there must be exactly one end_hub")
        links: set[frozenset[str]] = set()
        for c in self.connections:
            key = frozenset((c['zone1'], c['zone2']))
            if key in links:
                raise ValueError(
                    f"duplicate connection {c['zone1']}-{c['zone2']}")
            links.add(key)

    def create_a_dict(self, tags: str | None) -> dict[str, Any]:
        storage = {}
        if tags is None:
            return storage
        for line in tags.split():
            key, value = line.split('=')
            storage[key] = value
        # print(storage)
        return (storage)

    def give_default(self, storage: dict[str, Any],
                     defaults: dict[str, Any]) -> dict[str, str]:
        """Add the missing keys of `storage`, using `defaults`."""
        for key, value in defaults.items():
            storage.setdefault(key, value)
        return storage
