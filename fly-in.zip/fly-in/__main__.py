import sys
from parser import Parse


def main():
    if len(sys.argv) != 2:
        raise SystemExit("I only need 1 argument")
    try:
        io = Parse.open(sys.argv[1])
    except FileNotFoundError:
        raise SystemExit("File corrupted")


if __name__ == "__main__":
    main()
