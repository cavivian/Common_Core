import sys
from parse import Parsing, ParseError
from classes import Fleet


def main():
    if len(sys.argv) != 2:
        raise SystemExit("I only need 1 argument")
    try:
        io = Parsing(sys.argv[1])
        io.open()
        print(len(io.connections))
        print(len(io.zone))
        io = Fleet(io.zone, io.nb_drones, io.zone[-1])
        print(io.check_if_end())
        print(repr(f"sono qui {io.create_list_of_class_drones()}"))
    except FileNotFoundError:
        raise SystemExit(f"Error: file '{sys.argv[1]}' not found")
    except OSError as e:
        raise SystemExit(f"Error: cannot read '{sys.argv[1]}': {e.strerror}")
    except (ParseError, ValueError) as e:
        raise SystemExit(f"Error: {e}")


if __name__ == "__main__":
    main()
